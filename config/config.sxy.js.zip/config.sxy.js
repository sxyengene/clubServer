module.exports = {
  username:'root',
  password:'sxyengene',
  host:'47.99.96.170',
  database:'club',
}